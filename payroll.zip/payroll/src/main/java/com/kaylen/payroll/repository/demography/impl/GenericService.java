package com.mieshka.payroll.repository.demography.impl;

import com.mieshka.payroll.domain.demography.Gender;
import com.mieshka.payroll.repository.demography.GenderRepository;
import com.mieshka.payroll.domain.demography.Gender;
import com.mieshka.payroll.domain.demography.Gender;
import com.mieshka.payroll.domain.demography.Gender;
import com.mieshka.payroll.domain.demography.Gender;
import com.mieshka.payroll.domain.demography.Gender;


import java.util.*;

import static java.util.Locale.filter;

public class Employee crate  (String firstname,String lastname,String gendername,String raceName){
    Employee employee = EmployeeFactory.buildEmployess(employeeID "1",firstName,lastName);
    employeeService.create(employee);

    Race race = RaceFActory.buildRace (raceID"1" , raceName);

    Gender gender = GenderFactory.buildGender (genderId "1",genderName);
    genderService.create(gender);

    EmployeeGender employee = EmployeeGenderFactory.buildEmployeeGender(employeeID);
    employeeGenderService.create(employeeGender);

        }



}
